// UIPCHelloDlg.cpp : implementation file
//

#include "stdafx.h"
#include "UIPCHello.h"
#include "UIPCHelloDlg.h"
#include "FSUIPC.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUIPCHelloDlg dialog

CUIPCHelloDlg::CUIPCHelloDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CUIPCHelloDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CUIPCHelloDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CUIPCHelloDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUIPCHelloDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CUIPCHelloDlg, CDialog)
	//{{AFX_MSG_MAP(CUIPCHelloDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUIPCHelloDlg message handlers

BOOL CUIPCHelloDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	this->PopulateSimInfo();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CUIPCHelloDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}


HCURSOR CUIPCHelloDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CUIPCHelloDlg::PopulateSimInfo()
{
	char chTime[3];
	CString FSVersion("Unknown");
	CString	Version("Unknown");
	CString	FSClock("Unknown");
	static char *pFS[] = { "FS98", "FS2000", "CFS2", "CFS1", "Fly!", "FS2002" };
	
	/* Create a CFSUIPC object and connect to any simulator */
	CFSUIPC	FSConnection(SIM_ANY);
	
	/* Check to ensure we got connected */
	if (FSConnection.GetResultMessage() == 0)
	{
		/* Set FSVersion to the name of the simulator we are communicating with */
		FSVersion.Format("%s",pFS[FSConnection.GetFSVersion() - 1]);

		/* Set Version to the FSUIPC version number */
		Version.Format("%c.%c%c%c%c",
			'0' + (0x0f & (FSConnection.GetVersion() >> 28)),
			'0' + (0x0f & (FSConnection.GetVersion() >> 24)),
			'0' + (0x0f & (FSConnection.GetVersion() >> 20)),
			'0' + (0x0f & (FSConnection.GetVersion() >> 16)),
			(FSConnection.GetVersion() & 0xffff) ? 'a' + (FSConnection.GetVersion() & 0xff) - 1 : 0x0);

		/* Retrieve the FS Clock by issuing a read and process in one shot */
		if (FSConnection.ReadAndProcess(0x238, 3, chTime))
			FSClock.Format("%02d:%02d:%02d", chTime[0], chTime[1], chTime[2]);
	}

	/* Check for errors and display if necessary */
	if (FSConnection.GetResultMessage())
		MessageBox(FSConnection.GetResultMessageString());

	/* Set the dialog items text */
	this->SetDlgItemText(IDC_FSVERSION, FSVersion);
	this->SetDlgItemText(IDC_VERSION, Version);
	this->SetDlgItemText(IDC_FSCLOCK, FSClock);
}
