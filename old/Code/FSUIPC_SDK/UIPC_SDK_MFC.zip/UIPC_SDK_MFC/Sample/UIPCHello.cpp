// UIPCHello.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "UIPCHello.h"
#include "UIPCHelloDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUIPCHelloApp

BEGIN_MESSAGE_MAP(CUIPCHelloApp, CWinApp)
	//{{AFX_MSG_MAP(CUIPCHelloApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUIPCHelloApp construction

CUIPCHelloApp::CUIPCHelloApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CUIPCHelloApp object

CUIPCHelloApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CUIPCHelloApp initialization

BOOL CUIPCHelloApp::InitInstance()
{
	// Standard initialization

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	CUIPCHelloDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
	}
	else if (nResponse == IDCANCEL)
	{
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
