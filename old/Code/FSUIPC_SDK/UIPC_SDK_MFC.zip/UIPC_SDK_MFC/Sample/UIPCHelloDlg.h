// UIPCHelloDlg.h : header file
//

#if !defined(AFX_UIPCHELLODLG_H__CF23D3E8_7AA3_4F18_AA7A_DE791C1E50BF__INCLUDED_)
#define AFX_UIPCHELLODLG_H__CF23D3E8_7AA3_4F18_AA7A_DE791C1E50BF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CUIPCHelloDlg dialog

class CUIPCHelloDlg : public CDialog
{
// Construction
public:
	CUIPCHelloDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CUIPCHelloDlg)
	enum { IDD = IDD_UIPCHELLO_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUIPCHelloDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CUIPCHelloDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg HCURSOR OnQueryDragIcon();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void PopulateSimInfo();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_UIPCHELLODLG_H__CF23D3E8_7AA3_4F18_AA7A_DE791C1E50BF__INCLUDED_)
