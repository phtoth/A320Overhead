The .exe was built and run on Windows 2000 Professional with Borland C++ Builder5.03
and run successfully against FS98 and FS2002.

Can't swear as to whether will run on Windows 98, ME or XP, but should be OK. 

To use project 'as is' load into:

C:\Program Files\Borland\CBuilder5\Projects\FSHello

otherwise you will need to edit FSHello.bpr.