//---------------------------------------------------------------------------
#ifndef FSHelloMainH
#define FSHelloMainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
#define LIB_VERSION 1004 // 1.003
#define MAX_SIZE 0x7F00 // Largest data (kept below 32k to avoid

#define FS6IPC_MSGNAME1      "FsasmLib:IPC"

#define FS6IPC_MESSAGE_SUCCESS 1
#define FS6IPC_MESSAGE_FAILURE 0

// IPC message types
#define FS6IPC_READSTATEDATA_ID    1
#define FS6IPC_WRITESTATEDATA_ID   2

// Supported Sims
#define SIM_ANY	0
#define SIM_FS98	1
#define SIM_FS2K	2
#define SIM_CFS2	3
#define SIM_CFS1	4
#define SIM_F2K2	6

// Error numbers
#define FSUIPC_ERR_OK		0
#define FSUIPC_ERR_OPEN		1	// Attempt to Open when already Open
#define FSUIPC_ERR_NOFS		2	// Cannot link to FSUIPC or WideClient
#define FSUIPC_ERR_REGMSG	3	// Failed to Register common message with Windows
#define FSUIPC_ERR_ATOM		4	// Failed to create Atom for mapping filename
#define FSUIPC_ERR_MAP		5	// Failed to create a file mapping object
#define FSUIPC_ERR_VIEW		6	// Failed to open a view to the file map
#define FSUIPC_ERR_VERSION	7	// Incorrect version of FSUIPC, or not FSUIPC
#define FSUIPC_ERR_WRONGFS	8	// Sim is not version requested
#define FSUIPC_ERR_NOTOPEN	9	// Call cannot execute, link not Open
#define FSUIPC_ERR_NODATA	10	// Call cannot execute: no requests accumulated
#define FSUIPC_ERR_TIMEOUT	11	// IPC timed out all retries
#define FSUIPC_ERR_SENDMSG	12	// IPC sendmessage failed all retries
#define FSUIPC_ERR_DATA		13	// IPC request contains bad data
#define FSUIPC_ERR_RUNNING	14	// Maybe running on WideClient, but FS not running on Server, or wrong FSUIPC
#define FSUIPC_ERR_SIZE		15	// Read or Write request cannot be added, memory for Process is full

//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
    TStatusBar *StatusBar1;
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label3;
    TLabel *Label4;
    TLabel *Label5;
    TLabel *Label6;
    TLabel *Label7;
    TLabel *Label8;
    TLabel *Label9;
    TLabel *Label10;
    TTimer *Timer1;
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall Timer1Timer(TObject *Sender);

private:	// User declarations

public:		// User declarations

    // read request structure
    typedef struct tagFS6IPC_READSTATEDATA_HDR {
        DWORD dwId;       // FS6IPC_READSTATEDATA_ID
        DWORD dwOffset;   // state table offset
        DWORD nBytes;     // number of bytes of state data to read
        void* pDest;      // destination buffer for data (client use only)
    } FS6IPC_READSTATEDATA_HDR;

    // write request structure
    typedef struct tagFS6IPC_WRITESTATEDATA_HDR {
        DWORD dwId;       // FS6IPC_WRITESTATEDATA_ID
        DWORD dwOffset;   // state table offset
        DWORD nBytes;     // number of bytes of state data to write
    } FS6IPC_WRITESTATEDATA_HDR;

    DWORD FSUIPC_Version;
    DWORD FSUIPC_FS_Version;
    DWORD FSUIPC_Lib_Version;

    DWORD dwClosed;

    HWND    m_hWnd;       // FS6 window handle
    UINT    m_msg;        // id of registered window message
    ATOM    m_atom;       // global atom containing name of file-mapping object
    HANDLE  m_hMap;       // handle of file-mapping object
    BYTE*   m_pView;      // pointer to view of file-mapping object
    BYTE*   m_pNext;

    __fastcall TForm1(TComponent* Owner);
    void FSUIPC_Close(void);
    BOOL FSUIPC_Open(DWORD dwFSReq, DWORD *pdwResult);
    BOOL FSUIPC_Process(DWORD *pdwResult);
    BOOL FSUIPC_Read(DWORD dwOffset, DWORD dwSize, void *pDest, DWORD *pdwResult);
    BOOL FSUIPC_Write(DWORD dwOffset, DWORD dwSize, void *pSrce, DWORD *pdwResult);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
