//---------------------------------------------------------------------------
//
// Started:          9th November 2001
//
// With acknowledgements to Adam Szofran (author of original FS6IPC).
// With acknowledgements to Peter Dowson (author of original FSUIPC).
//
//---------------------------------------------------------------------------

#include <vcl.h>
#include <stdio.h>
#pragma hdrstop
#include "FSHelloMain.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
    FSUIPC_Version = 0;
    FSUIPC_FS_Version = 0;
    FSUIPC_Lib_Version = LIB_VERSION;

    m_hWnd = 0;       // FS6 window handle
    m_msg = 0;        // id of registered window message
    m_atom = 0;       // global atom containing name of file-mapping object
    m_hMap = 0;       // handle of file-mapping object
    m_pView = 0;      // pointer to view of file-mapping object
    m_pNext = 0;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
    char  String[32], chMsg[128], chTimeMsg[64];

    char *pFS[] = { "FS98", "FS2000", "CFS2", "CFS1", "Fly!", "FS2002" };

    char *pszErrors[] =
	{	"Okay",
		"Attempt to Open when already Open",
		"Cannot link to FSUIPC or WideClient",
		"Failed to Register common message with Windows",
		"Failed to create Atom for mapping filename",
		"Failed to create a file mapping object",
		"Failed to open a view to the file map",
		"Incorrect version of FSUIPC, or not FSUIPC",
		"Sim is not version requested",
		"Call cannot execute, link not Open",
		"Call cannot execute: no requests accumulated",
		"IPC timed out all retries",
		"IPC sendmessage failed all retries",
		"IPC request contains bad data",
		"Maybe running on WideClient, but FS not running on Server, or wrong FSUIPC",
		"Read or Write request cannot be added, memory for Process is full",
	};

	if (FSUIPC_Open(SIM_ANY, &dwClosed)) {

	        // Okay, we're linked, and already the FSUIPC_Open has had an initial
	        // exchange with FSUIPC to get its version number and to differentiate
	        // between FS's.

                sprintf(String, "%c.%c%c%c%c",
                        '0' + (0x0f & (FSUIPC_Version >> 28)),
	                '0' + (0x0f & (FSUIPC_Version >> 24)),
	                '0' + (0x0f & (FSUIPC_Version >> 20)),
	                '0' + (0x0f & (FSUIPC_Version >> 16)),
                        (FSUIPC_Version & 0xffff) ? 'a' + (FSUIPC_Version & 0xff) - 1 : ' ');

                Label10->Caption = String;
                Label4->Caption = pFS[FSUIPC_FS_Version - 1];
                
                StatusBar1->SimpleText = "Link established to FSUIPC";
	}

	else {

                StatusBar1->SimpleText = "Failed to open link to FSUIPC";
                Label6->Caption = pszErrors[dwClosed];
    }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormClose(TObject *Sender, TCloseAction &Action)
{
    FSUIPC_Close();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
    DWORD dwResult;
    char  String[32], chTime[3];
    BOOL fTimeOk = TRUE;

    if (!dwClosed) {

        if (!FSUIPC_Read(0x238, 3, chTime, &dwResult) ||
	    // If we wanted other reads/writes at the same time, we could put them here
	    !FSUIPC_Process(&dwResult)) // Process the request(s)
		fTimeOk = FALSE;

	// Now display all the knowledge we've accrued:
	if (fTimeOk) {
                Label2->Caption = "OK";
                sprintf(String, "%02d:%02d:%02d", chTime[0], chTime[1], chTime[2]);
                Label8->Caption = String;
        }
        else {
                Label2->Caption = "Failed";
        }
    }
}
//---------------------------------------------------------------------------
void TForm1::FSUIPC_Close(void)
{
    m_hWnd = 0;
	m_msg = 0;

	if (m_atom)
	{	GlobalDeleteAtom(m_atom);
		m_atom = 0;
	}

	if (m_pView)
	{	UnmapViewOfFile((LPVOID)m_pView);
		m_pView = 0;
	}

	if (m_hMap)
	{	CloseHandle(m_hMap);
		m_hMap = 0;
	}
}
//---------------------------------------------------------------------------
BOOL TForm1::FSUIPC_Open(DWORD dwFSReq, DWORD *pdwResult)
{
        char szName[MAX_PATH];
	static int nTry = 0;
	BOOL fWideFS = FALSE;
	int i = 0;

	// abort if already started
	if (m_pView)
	{	*pdwResult = FSUIPC_ERR_OPEN;
		return FALSE;
	}

	// Clear version information, so know when connected
	FSUIPC_Version = FSUIPC_FS_Version = 0;

	// Connect via FSUIPC, which is known to be FSUIPC's own
	// and isn't subject to user modificiation
	m_hWnd = FindWindowEx(NULL, NULL, "UIPCMAIN", NULL);
	if (!m_hWnd)
	{	// If there's no UIPCMAIN, we may be using WideClient
		// which only simulates FS98
		m_hWnd = FindWindowEx(NULL, NULL, "FS98MAIN", NULL);
		fWideFS = TRUE;
		if (!m_hWnd)
		{	*pdwResult = FSUIPC_ERR_NOFS;
			return FALSE;
		}
	}

	// register the window message
	m_msg = RegisterWindowMessage(FS6IPC_MSGNAME1);
	if (m_msg == 0)
	{	*pdwResult = FSUIPC_ERR_REGMSG;
		return FALSE;
	}

	// create the name of our file-mapping object
	nTry++; // Ensures a unique string is used in case user closes and reopens
	wsprintf(szName, FS6IPC_MSGNAME1 ":%X:%X", GetCurrentProcessId(), nTry);

	// stuff the name into a global atom
	m_atom = GlobalAddAtom(szName);
	if (m_atom == 0)
   {	*pdwResult = FSUIPC_ERR_ATOM;
		FSUIPC_Close();
		return FALSE;
	}

	// create the file-mapping object
	m_hMap = CreateFileMapping(
					(HANDLE)0xFFFFFFFF, // use system paging file
					NULL,               // security
					PAGE_READWRITE,     // protection
					0, MAX_SIZE+256,       // size
					szName);            // name

	if ((m_hMap == 0) || (GetLastError() == ERROR_ALREADY_EXISTS))
	{	*pdwResult = FSUIPC_ERR_MAP;
		FSUIPC_Close();
		return FALSE;
	}

	// get a view of the file-mapping object
	m_pView = (BYTE*)MapViewOfFile(m_hMap, FILE_MAP_WRITE, 0, 0, 0);
	if (m_pView == NULL)
	{	*pdwResult = FSUIPC_ERR_VIEW;
		FSUIPC_Close();
		return FALSE;
	}

	// Okay, now determine FSUIPC version AND FS type
	m_pNext = m_pView;

	// Try up to 5 times with a 100mSec rest between each
	// Note that WideClient returns zeroes initially, whilst waiting
	// for the Server to get the data
	while ((i++ < 5) && ((FSUIPC_Version == 0) || (FSUIPC_FS_Version == 0)))
	{	// Read FSUIPC version
		if (!FSUIPC_Read(0x3304, 4, &FSUIPC_Version, pdwResult))
		{	FSUIPC_Close();
			return FALSE;
		}

		// and FS version and validity check pattern
		if (!FSUIPC_Read(0x3308, 4, &FSUIPC_FS_Version, pdwResult))
		{	FSUIPC_Close();
			return FALSE;
		}

		// Write our Library version number to a special read-only offset
		// This is to assist diagnosis from FSUIPC logging
		// But only do this on first try
		if ((i < 2) && !FSUIPC_Write(0x330a, 2, &FSUIPC_Lib_Version, pdwResult))
		{	FSUIPC_Close();
			return FALSE;
		}

		// Actually send the requests and get the responses ("process")
		if (!FSUIPC_Process(pdwResult))
		{	FSUIPC_Close();
			return FALSE;
		}

		// Maybe running on WideClient, and need another try
		Sleep(100); // Give it a chance
	}

	// Only allow running on FSUIPC 1.998e or later
	// with correct check pattern 0xFADE
	if ((FSUIPC_Version < 0x19980005) || ((FSUIPC_FS_Version & 0xFFFF0000L) != 0xFADE0000))
	{	*pdwResult = fWideFS ? FSUIPC_ERR_RUNNING : FSUIPC_ERR_VERSION;
		FSUIPC_Close();
		return FALSE;
	}

	FSUIPC_FS_Version &= 0xffff; // Isolates the FS version number
	if (dwFSReq && (dwFSReq != FSUIPC_FS_Version)) // Optional user specific FS request
	{	*pdwResult = FSUIPC_ERR_WRONGFS;
		FSUIPC_Close();
		return FALSE;
	}

	*pdwResult = FSUIPC_ERR_OK;
	return TRUE;
}
//---------------------------------------------------------------------------
BOOL TForm1::FSUIPC_Process(DWORD *pdwResult)
{
        DWORD dwError;
	DWORD *pdw;
	FS6IPC_READSTATEDATA_HDR *pHdrR;
	FS6IPC_WRITESTATEDATA_HDR *pHdrW;
	int i = 0;

	if (!m_pView)
	{	*pdwResult = FSUIPC_ERR_NOTOPEN;
		return FALSE;
	}

	if (m_pView == m_pNext)
	{	*pdwResult = FSUIPC_ERR_NODATA;
		return FALSE;
	}

	ZeroMemory(m_pNext, 4); // Terminator
	m_pNext = m_pView;

	// send the request (allow up to 9 tries)
	while ((++i < 10) && !SendMessageTimeout(
			m_hWnd,       // FS6 window handle
			m_msg,        // our registered message id
			m_atom,       // wParam: name of file-mapping object
			0,            // lParam: offset of request into file-mapping obj
			SMTO_BLOCK,   // halt this thread until we get a response
			2000,	      // time out interval
			&dwError))    // return value
	{	Sleep(100); // Allow for things to happen
	}

	if (i >= 10) // Failed all tries?
	{	*pdwResult = GetLastError() == 0 ? FSUIPC_ERR_TIMEOUT : FSUIPC_ERR_SENDMSG;
		return FALSE;
	}

	if (dwError != FS6IPC_MESSAGE_SUCCESS)
	{	*pdwResult = FSUIPC_ERR_DATA; // FSUIPC didn't like something in the data!
		return FALSE;
	}

	// Decode and store results of Read requests
	pdw = (DWORD *) m_pView;

	while (*pdw)
	{	switch (*pdw)
		{	case FS6IPC_READSTATEDATA_ID:
				pHdrR = (FS6IPC_READSTATEDATA_HDR *) pdw;
				m_pNext += sizeof(FS6IPC_READSTATEDATA_HDR);
				if (pHdrR->pDest && pHdrR->nBytes)
					CopyMemory(pHdrR->pDest, m_pNext, pHdrR->nBytes);
				m_pNext += pHdrR->nBytes;
				break;

			case FS6IPC_WRITESTATEDATA_ID:
				// This is a write, so there's no returned data to store
				pHdrW = (FS6IPC_WRITESTATEDATA_HDR *) pdw;
				m_pNext += sizeof(FS6IPC_WRITESTATEDATA_HDR) + pHdrW->nBytes;
				break;

			default:
				// Error! So terminate the scan
				*pdw = 0;
				break;
		}

		pdw = (DWORD *) m_pNext;
	}

	m_pNext = m_pView;
	*pdwResult = FSUIPC_ERR_OK;
	return TRUE;
}
//---------------------------------------------------------------------------
BOOL TForm1::FSUIPC_Read(DWORD dwOffset, DWORD dwSize, void *pDest, DWORD *pdwResult)
{
        FS6IPC_READSTATEDATA_HDR *pHdr = (FS6IPC_READSTATEDATA_HDR *) m_pNext;

	// Check link is open
	if (!m_pView)
	{	*pdwResult = FSUIPC_ERR_NOTOPEN;
		return FALSE;
	}

	// Check have space for this request (including terminator)
	if (((m_pNext - m_pView) + 4 + (dwSize + sizeof(FS6IPC_READSTATEDATA_HDR))) > MAX_SIZE)
	{	*pdwResult = FSUIPC_ERR_SIZE;
		return FALSE;
	}

	// Initialise header for read request
	pHdr->dwId = FS6IPC_READSTATEDATA_ID;
	pHdr->dwOffset = dwOffset;
	pHdr->nBytes = dwSize;
	pHdr->pDest = (BYTE *) pDest;

	// Zero the reception area, so rubbish won't be returned
	if (dwSize) ZeroMemory(&m_pNext[sizeof(FS6IPC_READSTATEDATA_HDR)], dwSize);

	// Update the pointer ready for more data
	m_pNext += sizeof(FS6IPC_READSTATEDATA_HDR) + dwSize;

	*pdwResult = FSUIPC_ERR_OK;
	return TRUE;
}
//---------------------------------------------------------------------------
BOOL TForm1::FSUIPC_Write(DWORD dwOffset, DWORD dwSize, void *pSrce, DWORD *pdwResult)
{
        FS6IPC_WRITESTATEDATA_HDR *pHdr = (FS6IPC_WRITESTATEDATA_HDR *) m_pNext;

	// check link is open
	if (!m_pView)
	{	*pdwResult = FSUIPC_ERR_NOTOPEN;
		return FALSE;
	}

	// Check have spce for this request (including terminator)
	if (((m_pNext - m_pView) + 4 + (dwSize + sizeof(FS6IPC_WRITESTATEDATA_HDR))) > MAX_SIZE)
	{	*pdwResult = FSUIPC_ERR_SIZE;
		return FALSE;
	}

	// Initialise header for write request
	pHdr->dwId = FS6IPC_WRITESTATEDATA_ID;
	pHdr->dwOffset = dwOffset;
	pHdr->nBytes = dwSize;

	// Copy in the data to be written
	if (dwSize) CopyMemory(&m_pNext[sizeof(FS6IPC_WRITESTATEDATA_HDR)], pSrce, dwSize);

	// Update the pointer ready for more data
	m_pNext += sizeof(FS6IPC_WRITESTATEDATA_HDR) + dwSize;

	*pdwResult = FSUIPC_ERR_OK;
	return TRUE;
}
//---------------------------------------------------------------------------

