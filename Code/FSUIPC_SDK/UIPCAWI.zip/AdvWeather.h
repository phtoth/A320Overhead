/*  FSUIPC Advanced Weather Interface: Definitions
********************************************************/

// Command names (used as Address for IPC reads and writes)
// Add altitute in metres to "...AT" types, provide data structures
// with those marked *

// For use in WRITES only:
#define AW_ADDCAT 0x510000	 // *Add Cloud at
#define AW_ADDTAT 0x310000  // *Add Temperature at
#define AW_ADDVAT 0x110000	 // *Add Visibility at
#define AW_ADDWAT 0x410000  // *Add Wind at

#define AW_CLRALL	0x050000  //  Clear all weather
									 //   (resetting defaults where appropriate)
#define AW_CLRC   0x550000	 //  Clear all Cloud layers
#define AW_CLRP   0x250000  //  Clear Pressure (resets default)
#define AW_CLRT   0x350000  //  Clear all Temperature layers (resets default)
#define AW_CLRV   0x150000	 //  Clear all Visibility layers (resets default)
#define AW_CLRW   0x450000  //  Clear all Wind layers

#define AW_MODCAT 0x530000	 // *Modify Cloud at
#define AW_MODTAT 0x330000  // *Modify Temperature at
#define AW_MODVAT 0x130000	 // *Modify Visibility at
#define AW_MODWAT 0x430000  // *Modify Wind at

#define AW_REMCAT 0x520000	 //  Remove Cloud at
#define AW_REMTAT 0x320000  //  Remove Temperature at
#define AW_REMVAT 0x120000	 //  Remove Visibility at
#define AW_REMWAT 0x420000  //  Remove Wind at

#define AW_SETC   0x560000	 // *Set all Cloud layers
#define AW_SETP   0x260000  // *Set Pressure
#define AW_SETT   0x360000  // *Set all Temperature layers
#define AW_SETV   0x160000	 // *Set all Visibility layers
#define AW_SETW   0x460000  // *Set all Wind layers

// Adventure reporting overrides (in case of weather transitioning)
// For use with FSUIPC version 1.871 or later
// Send with no data structure if resetting the override, else see below for structures
#define AW_SETAC  0x570000	 // *Set ADVenture cloud values
#define AW_SETAP  0x270000  // *Set ADVenture pressure
#define AW_SETAV  0x170000	 // *Set ADVenture surface visibility
#define AW_SETAW  0x470000  // *Set ADVenture surface wind

// For use in READS only
#define AW_GETC   0x540000	 //  Read all Cloud layers
#define AW_GETP   0x240000  //  Read Pressure
#define AW_GETT   0x340000  //  Read all Temperature layers
#define AW_GETV   0x140000	 //  Read all Visibility layers
#define AW_GETW   0x440000  //  Read all set Wind layers
#define AW_GETW2  0x640000  //  Read all applied Wind layers
									 //   (eg applied after WindTransitions)

#define AW_GETCAT 0x500000	 //  Read Cloud at (at or above)
#define AW_GETTAT 0x300000  //  Read Temperature at (interpolated:
									 //    gives highest layer if alt above)
#define AW_GETVAT 0x100000	 //  Read Visibility at
									 //    (gives highest layer if alt above)
#define AW_GETWAT 0x400000  //  Read set Wind at
#define AW_GETW2AT 0x600000 // Read applied Wind at
									 //		(as applied after WindTransitions)

// Structures for data reads and writes

// N.B. ALWAYS use the Len value when calculating memory needs
// and incrementing through structures read: they might be changed
// if expanded facilities become available.

// This wind structure is used for all set winds
typedef struct _AdvWind
{	unsigned short Len;			// Length of this structure in bytes (16)
	short nAfter;					// Number of layers above this one
	unsigned short UpperAlt;	// Metres
	unsigned short Speed;		// Knots
	unsigned short	Gust;			// Max gust speed, knots
										//  (!! NB changed to difference for bug)
	unsigned short	Direction;	// usual 65536 = 360 units
	unsigned short	Turbulence;	// 0-4
	unsigned short	Shear;		// 0-3
} AdvWind;

// This wind struct is used only for reading applied winds
// (ie those actually simulated at the time)
typedef struct _AdvWind2
{	unsigned short Len;			// Length of this structure in bytes (24)
	short nAfter;					// Number of layers above this one
	unsigned short UpperAlt;	// Metres
	unsigned short Speed;		// Knots
	unsigned short	Gust;			// Max gust speed, knots
										//  (!! NB changed to difference for bug)
	unsigned short	Direction;	// usual 65536 = 360 units
	unsigned short	Turbulence;	// 0-4
	unsigned short	Shear;		// 0-3
	float fSpeed;					// Floating point speed in knots
										//  (for greater nav accuracy)
	float fDirection;				// Floating point direction in degrees True
										//  (for greater nav accuracy)
} AdvWind2;

typedef struct _AdvVis
{	unsigned short Len;			// Length of this structure in bytes (10)
	short nAfter;					// Number of layers above this one
	unsigned short UpperAlt;	// Metres
	unsigned short LowerAlt;	// Metres
	unsigned short Range;		// in 1/100ths sm
} AdvVis;

typedef struct _AdvCloud
{	unsigned short Len;			// Length of this structure in bytes (24)
	short nAfter;					// Number of layers above this one
	unsigned short UpperAlt;	// Metres
	unsigned short LowerAlt;	// Metres
	unsigned short Deviation;	// Metres
	unsigned short Coverage;	// Octas, 0-8
	unsigned short Type;			// 1-10
	unsigned short Turbulence;	// 0-4
	unsigned short Icing;		// 0-4
	unsigned short PrecipBase; // Metres
	unsigned short PrecipType; // 0-2
	unsigned short PrecipRate; // 0-5
} AdvCloud;

typedef struct _AdvTemp
{	unsigned short Len;			// Length of this structure in bytes (12)
	short nAfter;					// Number of layers above this one
	unsigned short Alt;			// Metres (interpolated alt for readings 'at')
	short Day;						// Degrees C (interpolated for
										//  interim altitude readings)
	short DayNightVar;			// Degrees C (interpolated for
										//  interim altitude readings)
	short DewPoint;				// Degrees C (interpolated for
										//  interim altitude readings)
} AdvTemp;

typedef struct _AdvPress
{	unsigned short Len;			// Length of this structure in bytes (8)
	short nAfter;					// Number of layers above this one (always 0)
	unsigned short Pressure;	// 16 x mb
	short Drift;					// ? Maybe, don't really know
										//   what this is ###############
} AdvPress;

/********************************************************************************
ADVENTURE WEATHER OVERRIDES
********************************************************************************/

// The following only apply when using FSUIPC version 1.871 or later:
// They are for ADVenture weather overrrides.
typedef struct _AdvADVcloud
{	unsigned short Len;			// Length of this structure in bytes (16 or 18)
	short nAfter;					// Number of layers above this one (always 0)
	
	// N.B. Due to FS98 limitations, the 3rd is only used when lowest is a Thunderstorm.
	unsigned short Coverage[3];	// Coverage in Octas for lowest 3 cloud layer
	unsigned short LowerAlt[3];	// Cloudbases in metres AMSL (0 = don't override this value)

	// Additional optional (1.96)
	unsigned short StationElevation; // Metres, reporting station

} AdvADVcloud;

/********************************************************************************
NOTES ON AdvADVcloud USAGE

1. If no AdvADVcloud structure is sent, the Adventure gets the current ones.

2. If AdvADVcloud data is received by FSUIPC, then the adventure gets ONLY the
   AdvADVclouds: nothing of the original ones are left to default, excepting
	possibly the station elevation if that isn't supplied as well.

3. If an empty or short structure is provided (i.e. one shorter than the 16 bytes
   needed for all three layers of coverage AND cloudbase), then the Adventure
	is told that there are no clouds at all. The shorter form (10 bytes) valid
	in FSUIPC versions before 1.963 is no longer supported.

4. The only complications arise when Thunderstorms are required. Normally:

		cloud[0] --> LOW CLOUD
		cloud[1] --> HIGH CLOUD
	
   and Thunderstorms are cleared. If three valid cloud layers are given, then 

		cloud[0] --> THUNDER STORM
		cloud[1] --> LOW CLOUD
		cloud[2] --> HIGH CLOUD

   The problem arises when you only want the thunderstorm, and no other,
	or only one other cloud layer. To indicate this you must do this:

		cloud[0] == thunderstorm details
		cloud[1] == optional LOW CLOUD details, else zeroes
		cloud[2] == Zero coverage, but non-zero cloudbase

	The value of the cloud[2] base is immaterial. It must simply be non-zero
	to show that cloud[0] is a thunderstorm, NOT "LOW CLOUD" as in the first
	case above.

********************************************************************************/

typedef struct _AdvADVwind
{	unsigned short Len;			// Length of this structure in bytes (8, 10 or 12)
	short nAfter;					// Number of layers above this one (always 0)
	unsigned short Speed;		// Knots
	unsigned short	Direction;	// usual 65536 = 360 units (degrees TRUE)

	// Additional optional (1.96)
	unsigned short MagVar;		// magvar at place reported (will be SUBTRACTED from dir to get degrees MAGNETIC)
										// N.B. If this is set to 0x8000 then the MagVar at the aircraft position is used instead
	// Additional optional (1.962)
	unsigned short Gust;			// Max gust speed, knots
} AdvADVwind;
	
typedef struct _AdvADVvis
{	unsigned short Len;			// Length of this structure in bytes (6)
	short nAfter;					// Number of layers above this one (always 0)
	unsigned short Range;		// in 1/100ths sm
} AdvADVvis;
	
typedef struct _AdvADVpress
{	unsigned short Len;			// Length of this structure in bytes (6)
	short nAfter;					// Number of layers above this one (always 0)
	unsigned short Pressure;	// 16 x mb
} AdvADVpress;
	
