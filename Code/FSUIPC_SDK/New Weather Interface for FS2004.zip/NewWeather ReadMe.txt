New Weather Interface for FS2004
================================

NOTES for PROGRAMMERS (REVISED 19th September 2003)


For FS2004 FSUIPC now offers three different ways of setting and reading the weather in Flight Sim:

1. The old rather limited FS98 compatible methods
2. The rather awkward "AWI" (Advanced Weather Interface) provided since FS2002
3. A "New Weather" interface, only effective from FS2004.

The NWI (New Weather Interface) is, like the original FS98 interface, completely memory mapped. The memory used is accessed through the FSUIPC interface at offsets C000-CFFF. This 4096 byte area is divided into 4 distinct sections of 1024 bytes each. The structures in all four are the same, and are defined in the enclosed Header file.

To avoid the confusing complications introduced in the AWI, you will see that there are fixed maxima on the numbers of layers -- 24 layers each, at most, of temperature, winds and clouds can be read/written

The four areas have specific uses, as follows:

C000-C3FF (Area 0): Weather at aircraft
=======================================

This is a read-only area which is updated continuously and gives full details of the weather at the aircraft. The "ulTimeStamp" entry changes everytime this is refreshed and gives the number of milliseconds since the FS session started. Of the structure members, only the following are valid:

	uDynamics -- provides the current dynamic setting (0=no change, 4=extreme)
	ulTimeStamp -- as just described
	plus all the weather entries
	
C400-C7FF (Area 1): Last set global weather
===========================================

This is a read only area which reflects the last complete set of GLOBAL weather set because of application writes through the FS98, AWI or NWI interfaces. 

Note that FS2004 doesn't really have "local" and "global" weather modes as such -- all weather is local, in fact, with areas with no data simply being filled in from the global setting. The "dynamic" option may be changing the weather differently locally in any case, whether originally derived from METAR or supplied data or from global values. As a consequence, the last weather set through the FS98 or AWI methods may not be reflected in the weather actually read back in Area 0 above. The differences can be seen by comparing Area 1 with Area 0.

Only the weather entries are valid in this structure.


C800-CBFF (Area 2): Weather setting area
========================================

The NWI is different in one important respect from both the older methods: when setting weather you set it ALL. In other words, you supply every aspect of the weather. There is no facility in FS2004 for modifying one item and leaving the others. FSUIPC has to supply the complete weather structure. For the FS98 and AWI methods, it does this by reading the global weather and modifying it with the entries changed by the application, then writing the whole lot back. This is not particularly efficient. In the NWI it is up to the application to do this, if that, indeed, is how it operates.

There are currently seven different operations which can be carried out through this area (see the Header supplied for definitions of the NW_ commands). Commands are written to the uCommand entry in the structure.

NW_DYNAMICS sets the FS2004 dynamic changes option to the value given in the uDynamics field. Write the latter first, then the command (in the same FSUIPC_Process is okay). A value of 0 sets dynamic changes off.

Note that the user's original setting is NOT restored. However, it isn't a permanent change - next time he loads FS it will be back to his original setting.
	
NW_CLEAR clears all weather, but does not change the dynamic option. If you want complete control over the weather, set dynamics to zero first.
	
NW_SET and NW_SETEXACT both set the complete weather either for the global setting or for a specific weather station identified by its ICAO (only! You do NOT have to specify its Latitude or Longitude -- if you do it will be ignored in any case.

NW_SET values are subject to the options and user weather filters provided by FSUIPC, just like the FS98 and AWI values are. This would include minima/maxima, smoothing, and so on.

NW_SETEXACT values bypass all filters and options. This is only really intended for programs like WidevieW, which apply copies of weather from one PC to another.

NW_SET_PENDING and NW_SETEXACT_PENDING are identical in every respect to these, except that the weather so set is not visually "activated" in FS2004. This may help performance when you want to set a number of weather stations. To activate it, send NW_ACTIVATE after the last such station in the batch. Note that any non-PENDING setting will effectively activate anything set pending before it. However, none of the AWI or FS98 methods of setting weather will override the pending situation -- in other words, you effectively stop everything external to FS changing the weather UNTIL you activate, or something external clears the weather.

Before writing these command values, you must set the rest of the structure to reflect the weather you require. You set the chICAO entry to the ICAO code for the station, or "GLOB" for the global setting.

Apart from the command, the ICAO entry, and the weather settings, only the ulTimeStamp is used -- this is set by FSUIPC to the time at which the specified weather was written to FS. Note that this is not confirmation that it succeeded. FSUIPC does not know whether the data was accepted or not -- if the ICAO station isn't recognised, the data will simply be ignored. It is not necessary that all stations or airports with ICAO codes are also weather stations. If the ICAO station did not exist in FS's database, the hICAO entry in this area will be reset to all zero, so you can avoid trying to send it again.

IMPORTANT NOTES: FS2004 has complicated mechanisms in its weather system which deal with interpolation between stations, "morphing" weather changes, and, of course, the dynamic changes. It also has weather scenarios which sort-of follow scripts. I have no control over any of this. If you truly want to impose your weather onto the FS landscape, then you need to start off by (a) switching dynamics off, and (b) clearing all weather. If you don't, then the results may not be what you expected and may, indeed, be rather a mess.

For a complete weather-setting program, I recommend something like this:

a) Set dynamics to zero, then clear all weather. This can be done in one FSUIPC_Process. Leave a little delay afterwards.

b) Set a suitable default weather for Global -- this is the weather you want to "fill in" any large gaps in the METAR station network, such as over Oceans. Sorry, I have no idea *when* FS starts using this weather. You'd have to experiment to find out. But it will also use it at any stations you don't set, whether because you don't want to or because they don't feature in your own downloads.

To set Global weather, use NW_SET with an ICAO= "GLOB". WAIT TILL THE TIMESTAMP HAS CHANGED before changing the C800-CBFF are and doing another NW_SET or SETEXACT!

c) For each Metar station in the vicinity of the aircraft, set its weather. How far you go is up to you -- if you want WX Radars to work well you probably need to cover at least 40 miles all around. This will take some time, so only do this once, unless the user explicitly presses a "refresh" button or similar.

Don't forget to avoid changing the area until the timestamp has changed.

d) As the aircraft is moving, re-evaluate those WX stations which should be supplied with weather, and only update the ones that need to be so updated. To avoid introducing stutters try to pace this out.

e) If you are updating weather in real time, only update those Wx stations already set if there are significant changes, and try to pace those too.

Here's the correct sequence for setting the weather:

	1 read timestamp (an FSUIPC read)

	2 write station (one or more FSUIPC Writes)
	3 FSUIPC Process call
	4 save the timestamp read as "x" 

	5 read timestamp (an FSUIPC read)
	6 FSUIPC Process call
	7 if timestamp not yet changed from "x", loop to 5 (at next time interval*) 
	8 save new timestamp as 'x' 

	9 continue at 2 till done all weather stations
	
* Don't forget to process windows messages in this wait loop. Best to run each pass on a timer call or similar.

I hope this is clear. This "timestamp" business is a hand-shaking protocol -- there's only one set of weather data being processed in FSUIPC at a time, so you have to know it's done one before sending the next. 


CC00-CFFF (Area 3): Weather reading area
========================================

This is the most complex area to use, because it can provide the complete weather structure for any known weather station given its ICAO. Since the data has to be read, on request, and be made available for a time so that the application can actually read it all, an interlocking mechanism is provided to prevent another application from trying to read a new location within a reasonable time.

The procedure is as follows:

1. The application generates a "signature", any 32-bit pseudo-random number. It will use this as its temporary access key into this area.

2. Each time it wants to read weather for a station, it writes the signature to the ulSignature field and the ICAO to the chICAO field, AT THE SAME TIME -- i.e. a write of 8 bytes altogether. If it wants to read the weather at a specific location instead, not at a station, then the ICAO code should be set instead to 4 spaces ("    ") and the Latitude and Longitude fields should be written at the same time as the signature and this blank ICAO code. That makes a total of 28 bytes written (the dynamics and spare fields can be set zero. they are ignored).

3. If the area is free (signature is zero) or this signature is the same as the last one written, then this access works, and FSUIPC obtains the requested weather. If, however, the signature does not match and someone else is reading the weather here, this write will be discarded and nothing will be done. A program which wants to be cooperative can use a signature of zero -- this works providing it is zero already, but it doesn't stop any other program from reading whatever it likes. The program which is being so friendly must be prepared to see a different ICAO or location being read than the one it asked for -- the WeatherSet2 program does this. You can ask it to display any location or WX sttion, but it will display whatever any other program is reading too, or, rather, instead.

4. FSUIPC clears down the signature approximately 14 seconds (at most) after it is validly written, thus opening up access to all again. If you want to keep the access for your own program you have to refresh the signature within this time, say every 5-8 seconds to be safe.

5. If the request succeeds, then at some time later (a few milliseconds probably, depending on FS frame rates) the weather details will be filled in and the chICAO field will reflect which weather station this is for. Furthermore, the ulTimeStamp field will be updated, and the Latitude, Longitude and Elevation of the ICAO station will be valid. If the request fails the weather at the aircraft is substituted, and if that fails the GLOBal weather is substituted. In the former case the ICAO id will be zeroed and the aircraft Lat/Lon set. In the latter case the ICAO identifier will be changed to 'GLOB'.

If programs want to check that the weather provided genuinely is for the location they requested, they should read the ICAO and/or Lat/Lon back in the same Process call as reading the weather data, and check that they are as they requested.

6. FSUIPC keeps the data updated at roughly 1 second intervals. The weather data should always reflect the ICAO code or Lat/Lon actually readable in this area. If the signature expires (i.e. it is not refreshed in time), then, since version 3.499a of FSUIPC, these updates still continue. Before any valid requests are made in an FS session, the area is updated with weather at the aircraft position, and the LLatitude and Longitude fields are updated accordingly.

Note that you can read the global weather settings here by setting the ICAO to "GLOB". In this case the Latitude/Longitude/Elevation values will all be zero.


WEATHERSET2
===========

This is a special version of WeatherSet which uses only the above facilities, no others. By default it will read the weather at the aircraft location (i.e. Area 0 above). You cannot modify that. To select a specific station, place the cursor in the station window and press Return. then you can enter an ICAO, or, for the default global settings, GLOB. If the ICAO gives a valid weather station listed in FS2004 then you will see its weather, plus the latitude longitude and alititude of the station, from Area 3 above. You can also request weather at a given Latitude/Longitude.

For GLOB and station weather (only) you can edit any of the weather as in previous versions of WeatherSet: RETURN = edit an entry, INSERT = insert a new entry, DELETE = delete an entry. The latter two are only relevant for those with layers (winds, temperature and clouds). SEE NOTE BELOW about a current FS2004 problem with wind and temperature layers!

To get WeatherSet back to showing the weather at the aircraft, edit the station but enter no station code, just press return.


SOME NOTES ON FS2004 DIFFERENCES IN WEATHER
===========================================

1. For variable wind directions (like "210V240"), rather than have the external program constantly changing the wind direction, it is now better to set the Wind Variance value. You can do this via the NWI. I don't know, however, if this value is the *total* variance (eg 30 in the example 210V240) or an each-way variance (which would be 15 in this example). I'm pretty sure, though, that in both cases you'd supply the 'central' value (225). If you find out whether it's total or each way, please let me know so I can document it.

2. The upper wind altitude for the surface wind is specified as AMSL for global weather (naturally), but the value used inside FS is adjusted by the local station's elevation, so in fact is is APPLIED as AGL. I think, in fact, this may have been the case also in FS2002, but I tried to "fix" what looked like subterranean winds in some places! The latter was really exacerbated by the confusion of FSUIPC's wind transitioning system replacing all the layers in any case.

I think the AMSL/AGL thing works okay -- I'm trying to adjust it correctly inside FSUIPC to "do the right thing", but it is something to watch out for. You will see differences by reading the weather with WeatherSet2 (as supplied) and comparing this with that read by the older WeatherSet (you already have) -- the latter shows the AGL which remains the same for a globally set scenario, but you'll see the AMSL in WeatherSet2, which reads the NWI version after it is adjusted. Different WX stations have different AMSL values for the surface wind because of different elevations.



=================================================
Peter L. Dowson, 19th September 2003
=================================================
