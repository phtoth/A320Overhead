Option Explicit On 

Imports System
Imports Microsoft.VisualBasic.DateAndTime
Imports System.IntPtr
Imports System.Runtime.InteropServices

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'Form1
        '
        Me.AccessibleName = "FSTrace"
        Me.AccessibleRole = System.Windows.Forms.AccessibleRole.TitleBar
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.Gray
        Me.ClientSize = New System.Drawing.Size(1016, 497)
        Me.ForeColor = System.Drawing.Color.Black
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim dwResult As Integer

        FSUIPC_Initialization()
        If (Not FSUIPC_Open(SIM_ANY, dwResult)) Then
            'Cant_Open()
            End
        End If
        'Call main procedure here
    End Sub

 
    'ToggleBit chenges respective bit in status byte, returns new toggled value of bit
    Private Function ToggleBit(ByRef statusbyte As Byte, ByVal BitNum As Integer) As Boolean
        Dim temp, Mask As Byte
        If BitNum > 7 Then BitNum = 0
        temp = statusbyte
        Mask = 2 ^ BitNum
        If (Mask And statusbyte) = 0 Then    'Bit was off
            statusbyte = statusbyte Or Mask

            Return True
        Else
            statusbyte = statusbyte Xor Mask
            Return False
        End If
    End Function

    'TestBit returns value of specified bit in status byte
    Private Function TestBit(ByVal statusbyte As Byte, ByVal BitNum As Integer) As Boolean
        Dim Mask As Byte
        If BitNum > 7 Then BitNum = 0
        Mask = 2 ^ BitNum
        If (Mask And statusbyte) = 0 Then    'Bit was off
            Return False
        Else
            Return True
        End If
    End Function


    ' ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    '   Visual Basic <-> FSUIPC/WideFS Communication                 Version 2.004
    '   Copyright � 2000 Chris Brett.  All rights reserved.          31 Jul 2004
    '   e-mail: chris@formulate.clara.net
    '
    '   Rewritten for Visual Basic .NET By Bob Scott
    '   e-mail w6kd@amsat.org
    '
    '   FUNCTION LIBRARY FOR FSUIPC
    '   based on C code supplied by Pete Dowson
    '
    '   BASIC USAGE GOES LIKE THIS:
    '     - call FSUIPC_Initialization() to initialize important vars at beginning
    '       of program.
    '     - call FSUIPC_Open() to connect with FSUIPC if it's available.
    '     - call a series of FSUIPC_Read and/or FSUIPC_Write and/or FSUIPC_WriteS (be careful when
    '       combining these in the one transaction, for your own sanity).
    '     - call FSUIPC_Process() to actually get/set the data from/to FS.
    '     - For reads, call FSUIPC_Get to retrieve data read from FSUIPC (New for VB .Net)
    '     - repeat steps 3, 4, and 5 as necessary
    '     - at program termination, call FSUIPC_Close().
    '
    ' ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    'Sub FSUIPC_Initialization()
    '
    'Sub FSUIPC_Close()
    '
    'Function FSUIPC_Read(ByVal dwOffset As Integer, ByVal dwSize As Integer, ByRef Token As Integer, _
    '                     ByRef dwResult As Integer) As Boolean
    '
    'Overloads Function FSUIPC_Get(ByRef Token As Integer, ByRef Result As Byte/Short/Integer/Long/Double) As Boolean
    '
    'Overloads Function FSUIPC_Get(ByRef Token As Integer, ByVal dwSize As Integer, ByRef Result As Byte()) _
    '                              As Boolean
    '
    'Overloads Function FSUIPC_Write(ByVal dwOffset As Integer, ByVal Param As Byte/Short/Integer/Long/Double, _
    '                                ByRef Token As Integer, ByRef dwResult As Integer) As Boolean
    '
    'Overloads Function FSUIPC_Write(ByVal dwOffset As Integer, ByVal dwSize As Integer, ByVal Param As Byte(), _
    '                                ByRef Token As Integer, ByRef dwResult As Integer) As Boolean
    '
    ' **************************************************************************************
    ' ***************  VISUAL BASIC .NET EXTERNAL PROCEDURE REFERENCES *********************
    ' **************************************************************************************
    '
    ' IMPORTANT NOTE:  These headers have changed in VB .NET  Integer replaces Long for most args and
    ' all ByRef args must be explicitly declared
    '

    Declare Sub ZeroMemory Lib "kernel32.dll" Alias "RtlZeroMemory" (ByVal Destination As IntPtr, ByVal _
            Length As Integer)

    Declare Sub CopyMemory Lib "kernel32" Alias "RtlMoveMemory" (ByVal pDest As IntPtr, ByVal pSrc As IntPtr, _
                                                                 ByVal ByteLen As Integer)

    Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Integer)

    Declare Function FindWindowEx Lib "user32" Alias "FindWindowExA" (ByVal hWnd1 As Integer, ByVal hWnd2 As Integer, _
            ByVal lpsz1 As String, ByVal lpsz2 As String) _
            As Integer

    Declare Function RegisterWindowMessage Lib "user32" Alias "RegisterWindowMessageA" (ByVal lpString As String) _
            As Integer

    Declare Function GetCurrentProcessId Lib "kernel32" () As Integer

    Declare Function GlobalAddAtom Lib "kernel32" Alias "GlobalAddAtomA" (ByVal lpString As String) As Integer

    Declare Function CreateFileMapping Lib "kernel32" Alias "CreateFileMappingA" (ByVal hFile As Integer, _
            ByVal lpFileMappigAttributes As Integer, ByVal flProtect As Integer, _
            ByVal dwMaximumSizeHigh As Integer, ByVal dwMaximumSizeLow As Integer, ByVal lpName As String) As Integer

    Declare Function GetLastError Lib "kernel32" () As Integer

    Declare Function MapViewOfFile Lib "kernel32" (ByVal hFileMappingObject As Integer, ByVal _
            dwDesiredAccess As Integer, ByVal dwFileOffsetHigh As Integer, ByVal dwFileOffsetLow As Integer, ByVal _
            dwNumberOfBytesToMap As Integer) As Integer

    Declare Function MapViewOfFileEx Lib "kernel32" (ByVal hFileMappingObject As Integer, ByVal _
            dwDesiredAccess As Integer, ByVal dwFileOffsetHigh As Integer, ByVal dwFileOffsetLow As Integer, ByVal _
            dwNumberOfBytesToMap As Integer, ByVal lpBaseAddress As IntPtr) As Integer

    Declare Function GlobalDeleteAtom Lib "kernel32" (ByVal nAtom As Integer) As Integer

    Declare Function UnmapViewOfFile Lib "kernel32" (ByVal lpBaseAddress As IntPtr) As Integer

    Declare Function CloseHandle Lib "kernel32" (ByVal hObject As Integer) As Integer

    Declare Function SendMessageTimeout Lib "user32" Alias "SendMessageTimeoutA" (ByVal hwnd As Integer, ByVal _
            msg As Integer, ByVal wParam As Integer, ByVal lParam As Integer, ByVal fuFlags As Integer, ByVal _
            uTimeout As Integer, ByRef lpdwResult As Integer) As Integer


    Public Const SMTO_ABORTIFHUNG = &H2
    Public Const SMTO_BLOCK = &H1
    Public Const PAGE_READWRITE = 4&
    Public Const NO_ERROR = 0
    Public Const ERROR_ALREADY_EXISTS = 183&
    Public Const SECTION_MAP_WRITE = &H2
    Public Const FILE_MAP_WRITE = SECTION_MAP_WRITE


    ' **************************************************************************************
    ' ************************** FSUIPC SPECIFICS ******************************************
    ' **************************************************************************************

    ' Supported Sims
    Public Const SIM_ANY = 0
    Public Const SIM_FS98 = 1
    Public Const SIM_FS2K = 2
    Public Const SIM_CFS2 = 3
    Public Const SIM_CFS1 = 4
    Public Const SIM_FLY = 5
    Public Const SIM_FS2K2 = 6
    Public Const SIM_FS2K4 = 7
    Public Const SIM_FSX = 8
    Public Const SIM_ESP = 9

    ' Error numbers
    Public Const FSUIPC_ERR_OK = 0
    Public Const FSUIPC_ERR_OPEN = 1              ' Attempt to Open when already Open
    Public Const FSUIPC_ERR_NOFS = 2              ' Cannot link to FSUIPC or WideClient
    Public Const FSUIPC_ERR_REGMSG = 3            ' Failed to Register common message with Windows
    Public Const FSUIPC_ERR_ATOM = 4              ' Failed to create Atom for mapping filename
    Public Const FSUIPC_ERR_MAP = 5               ' Failed to create a file mapping object
    Public Const FSUIPC_ERR_VIEW = 6              ' Failed to open a view to the file map
    Public Const FSUIPC_ERR_VERSION = 7           ' Incorrect version of FSUIPC, or not FSUIPC
    Public Const FSUIPC_ERR_WRONGFS = 8           ' Sim is not version requested
    Public Const FSUIPC_ERR_NOTOPEN = 9           ' Call cannot execute, link not Open
    Public Const FSUIPC_ERR_NODATA = 10           ' Call cannot execute: no requests accumulated
    Public Const FSUIPC_ERR_TIMEOUT = 11          ' IPC timed out all retries
    Public Const FSUIPC_ERR_SENDMSG = 12          ' IPC sendmessage failed all retries
    Public Const FSUIPC_ERR_DATA = 13             ' IPC request contains bad data
    Public Const FSUIPC_ERR_RUNNING = 14          ' Maybe running on WideClient, but FS not running on Server, or wrong FSUIPC
    Public Const FSUIPC_ERR_SIZE = 15
    Public Const FSUIPC_ERR_BUFOVERFLOW = 16

    Public Const IPC_BUFFER_SIZE = 65568
    Public Const LEN_RD_HDR = 16                  ' Length of an IPC Read Header (4x 4-byte Integers)
    Public Const LEN_WR_HDR = 12                  ' Length of an IPC Write Header (3x 4-byte Integers)

    Public Structure DWORD
        Dim Byt0 As Byte
        Dim Byt1 As Byte
        Dim Byt2 As Byte
        Dim Byt3 As Byte
    End Structure

    ' global variables for the UIPC communication
    Public IPC(IPC_BUFFER_SIZE) As Byte         'IPC Data Buffer
    Public IPCdr(IPC_BUFFER_SIZE) As Boolean    'Data waiting flags
    Public IPCAlloc As Integer                  'Data Buffer Allocation Index
    Public FSUIPC_Version As Integer
    Public FSUIPC_FS_Version As Integer
    Public FSUIPC_Lib_Version As Integer
    Public m_hWnd As Integer       ' FS window handle
    Public m_msg As Integer        ' ID of registered window message
    Public m_atom As Integer       ' global atom containing name of file-mapping object
    Public m_hMap As Integer       ' handle of file-mapping object
    Public m_pView As Integer      ' pointer to view of file-mapping object
    Public m_pNext As Integer      ' pointer into FSUIPC data buffer area

    '***** Program Var Area *****
    '/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\



    '/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
    '***END Program Var Area

    Public Const LIB_VERSION = 2003              ' 2.003
    Public Const MAX_SIZE = &H7F00&              ' Largest data (kept below 32k to avoid
    ' any possible 16-bit sign problems
    Public Const MAX_REQ_SIZE = 1024             ' Maximum single request block size

    Public Const FS6IPC_MSGNAME1 = "FSASMLIB:IPC"
    Public Const FS6IPC_MSGNAME2 = "EFISFSCOM:IPC"
    Public Const FS6IPC_MESSAGE_SUCCESS = 1
    Public Const FS6IPC_MESSAGE_FAILURE = 0

    ' IPC message types
    Public Const FS6IPC_READSTATEDATA_ID = 1
    Public Const FS6IPC_WRITESTATEDATA_ID = 2
    Public Const FS6IPC_SPECIALREQUEST_ID = &HABAC


    'Program Const area
    '/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\



    '/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/

    '*** END Program Const area

    Public Structure FS6IPC_READSTATEDATA_HDR
        Public dwId As Integer
        Public dwOffset As Integer
        Public nBytes As Integer
        Public pDest As IntPtr
    End Structure

    Public Structure FS6IPC_WRITESTATEDATA_HDR
        Public dwId As Integer
        Public dwOffset As Integer
        Public nBytes As Integer
    End Structure

    Public Structure SEC_ATTRIBUTES
        Public nLength As Integer
        Public lpSecurityDescriptor As Integer
        Public bInheritHandle As Integer
    End Structure

    Public Overloads Sub Toggle(ByRef Arg1 As Byte)
        If Arg1 = 0 Then
            Arg1 = 1
        Else
            Arg1 = 0
        End If
    End Sub

    Public Overloads Sub Toggle(ByRef Arg1 As Short)
        If Arg1 = 0 Then
            Arg1 = 1
        Else
            Arg1 = 0
        End If
    End Sub

    Public Overloads Sub Toggle(ByRef Arg1 As Integer)
        If Arg1 = 0 Then
            Arg1 = 1
        Else
            Arg1 = 0
        End If
    End Sub

    '--- Stop the Client ---------------------------------------------------------

    Sub FSUIPC_Close()

        m_hWnd = 0
        m_msg = 0
        m_pNext = 0

        If (m_atom <> 0) Then
            GlobalDeleteAtom(m_atom)
            m_atom = 0
        End If

        If (m_pView <> 0) Then
            Dim _pView As IntPtr = New IntPtr(m_pView)
            UnmapViewOfFile(_pView)
            m_pView = 0
        End If

        If (m_hMap <> 0) Then
            CloseHandle(m_hMap)
            m_hMap = 0
        End If

    End Sub



    Sub FSUIPC_Initialization()
        Dim idx As Integer = 0
        For idx = 0 To IPC_BUFFER_SIZE
            IPC(idx) = 0
            IPCdr(idx) = False
        Next
        IPCAlloc = 0
        m_hWnd = 0
        m_msg = 0
        m_atom = 0
        m_hMap = 0
        m_pView = 0
        m_pNext = 0
    End Sub


    '--- Start the Client --------------------------------------------------------
    ' returns TRUE if successful, FALSE otherwise,
    ' if FALSE dwResult contains the "error-code"

    Function FSUIPC_Open(ByVal dwFSReq As Integer, ByRef dwResult As Integer) As Boolean
        Dim szName, szTemp As String '* 24
        Dim pszName As IntPtr
        Dim fWideFS As Boolean
        Dim nTry As Integer
        Dim i As Integer

        ' initialize vars
        nTry = 0
        fWideFS = False
        i = 0
        FSUIPC_Version = 0
        FSUIPC_FS_Version = 0

        ' abort if already started
        If m_pView <> 0 Then
            dwResult = FSUIPC_ERR_OPEN
            FSUIPC_Open = False
            Exit Function
        End If

        ' Connect via FSUIPC, which is known to be FSUIPC's own
        ' and isn't subject to user modification

        m_hWnd = FindWindowEx(0, 0, "UIPCMAIN", vbNullString)
        If (m_hWnd = 0) Then
            ' If there's no UIPCMAIN, we may be using WideClient
            ' which only simulates FS98
            m_hWnd = FindWindowEx(0, 0, "FS98MAIN", vbNullString)
            fWideFS = True
            If (m_hWnd = 0) Then
                dwResult = FSUIPC_ERR_NOFS
                FSUIPC_Open = False
                Exit Function
            End If
        End If

        ' register the window message
        m_msg = RegisterWindowMessage(FS6IPC_MSGNAME1)
        If (m_msg = 0) Then
            dwResult = FSUIPC_ERR_REGMSG
            FSUIPC_Open = False
            Exit Function
        End If

        ' create the name of our file-mapping object
        nTry = nTry + 1 ' Ensures a unique string is used in case user closes and reopens
        szName = FS6IPC_MSGNAME1 & ":" & Hex(GetCurrentProcessId()) & ":" & Hex(nTry) & Chr(0)
        If (szName.Length > 23) Then    '24 chars max
            szName = szName.Substring(0, 23) & Chr(0)
        End If

        ' stuff the name into a global atom
        m_atom = GlobalAddAtom(szName)

        If (m_atom = 0) Then
            dwResult = FSUIPC_ERR_ATOM
            FSUIPC_Close()
            FSUIPC_Open = False
            Exit Function
        End If

        ' create the file-mapping object
        ' use system paging file
        ' security attrubute (0 = cannot inherit)
        ' protection
        ' size
        ' name

        m_hMap = CreateFileMapping(&HFFFFFFFF, 0&, PAGE_READWRITE, 0&, MAX_SIZE + 256, szName)

        If (m_hMap = 0) Or (GetLastError() = ERROR_ALREADY_EXISTS) Then
            dwResult = FSUIPC_ERR_MAP
            FSUIPC_Close()
            FSUIPC_Open = False
            Exit Function
        End If

        ' spawn a view of the file-mapping object
        m_pView = MapViewOfFile(m_hMap, FILE_MAP_WRITE, 0&, 0&, 0&)

        If m_pView = 0 Then
            dwResult = FSUIPC_ERR_VIEW
            FSUIPC_Close()
            FSUIPC_Open = False
            Exit Function
        End If

        ' Okay, now determine FSUIPC version AND FS type
        m_pNext = m_pView

        ' Try up to 5 times with a 100msec rest between each
        ' Note that WideClient returns zeros initially, whilst waiting
        ' for the Server to get the data
        Do
            i = i + 1
            ' Read FSUIPC version
            Dim t_FSUIPC_Version As Integer

            If (Not FSUIPC_Read(&H3304, 4, t_FSUIPC_Version, dwResult)) Then
                FSUIPC_Close()
                FSUIPC_Open = False
                Exit Function
            End If

            ' and FS version and validity check pattern
            Dim t_FSUIPC_FS_Version As Integer
            If (Not FSUIPC_Read(&H3308, 4, t_FSUIPC_FS_Version, dwResult)) Then
                FSUIPC_Close()
                FSUIPC_Open = False
                Exit Function
            End If

            ' write our Library version number to a special read-only offset
            ' This is to assist diagnosis from FSUIPC logging
            ' But only do this on first try
            Dim t_FSUIPC_Lib_Version As Integer
            If (i < 2) And (Not FSUIPC_Write(&H330A, 2, t_FSUIPC_Lib_Version, dwResult)) Then
                FSUIPC_Close()
                FSUIPC_Open = False
                Exit Function
            End If

            ' Actually send the request and get the responses ("process")

            If Not (FSUIPC_Process(dwResult)) Then
                FSUIPC_Close()
                FSUIPC_Open = False
                Exit Function
            End If

            Dim VersionGet As Boolean = FSUIPC_Get(t_FSUIPC_Version, FSUIPC_Version)
            VersionGet = FSUIPC_Get(t_FSUIPC_FS_Version, FSUIPC_FS_Version)
            VersionGet = FSUIPC_Get(t_FSUIPC_Lib_Version, FSUIPC_Lib_Version)

            ' Maybe running on WideClient, and need another try
            Call Sleep(100) ' Give it a chance
        Loop While ((i < 5) And ((FSUIPC_Version = 0) Or (FSUIPC_FS_Version = 0)))


        ' Only allow running on FSUIPC 1.998e or later
        ' with correct check pattern &HFADE
        If ((FSUIPC_Version < &H19980005) Or ((FSUIPC_FS_Version And &HFFFF0000) <> &HFADE0000)) Then
            If fWideFS Then dwResult = FSUIPC_ERR_RUNNING Else dwResult = FSUIPC_ERR_VERSION
            FSUIPC_Close()
            FSUIPC_Open = False
            Exit Function
        End If

        ' grab the FS version number
        FSUIPC_FS_Version = (FSUIPC_FS_Version And &HFFFF&)

        ' Optional version-specific request made?  If so and wrong version, return error
        If (dwFSReq <> 0) And (dwFSReq <> FSUIPC_FS_Version) Then
            dwResult = FSUIPC_ERR_WRONGFS
            FSUIPC_Close()
            FSUIPC_Open = False
            Exit Function
        End If
        dwResult = FSUIPC_ERR_OK
        FSUIPC_Open = True
    End Function

    ' Retrieve data read from FSUIPC using token passed during read request
    ' Data is stored in byte array IPC when FSUIPC_Process is called
    ' Six overloaded function defs, all return True if successful, false if failed, data passed with ByRef arg
    ' Four are called with result=FSUIPC_Get(Token, Result) where result is byte, short, integer, long, or double
    ' Sixth is called with result=FSUIPC_Get(Token, dwSize, Result) where dwSize is # of bytes in block to
    '        retrieve, and result is an array of bytes

    Overloads Function FSUIPC_Get(ByRef Token As Integer, ByRef Result As Byte) As Boolean
        Dim Size As Integer = 1    ' 1 byte
        If (Token < 0) Or (Token > IPC_BUFFER_SIZE - (4 + Size)) Then 'Token out of range
            Result = 0
            FSUIPC_Get = False
            Exit Function
        End If
        Result = IPC(Token + 4)
        If IPCdr(Token) Then
            IPCdr(Token) = False    ' reset data ready flag
            FSUIPC_Get = True
        Else                        ' If data ready flag not set, function returns FALSE and old buffer value
            FSUIPC_Get = False
        End If
    End Function


    Overloads Function FSUIPC_Get(ByRef Token As Integer, ByRef Result As Short) As Boolean
        Dim Size As Integer = 2    ' 2 bytes in a short
        If (Token < 0) Or (Token > IPC_BUFFER_SIZE - (4 + Size)) Then 'Token out of range
            Result = 0
            FSUIPC_Get = False
            Exit Function
        End If
        Result = BitConverter.ToInt16(IPC, Token + 4)
        If IPCdr(Token) Then
            IPCdr(Token) = False    ' reset data ready flag
            FSUIPC_Get = True
        Else                        ' If data ready flag not set, function returns FALSE and old buffer value
            FSUIPC_Get = False
        End If
    End Function

    Overloads Function FSUIPC_Get(ByRef Token As Integer, ByRef Result As Integer) As Boolean
        Dim Size As Integer = 4    ' 2 bytes in an integer
        If (Token < 0) Or (Token > IPC_BUFFER_SIZE - (4 + Size)) Then 'Token out of range
            Result = 0
            FSUIPC_Get = False
            Exit Function
        End If
        Result = BitConverter.ToInt32(IPC, Token + 4)
        If IPCdr(Token) Then
            IPCdr(Token) = False
            FSUIPC_Get = True
        Else    ' If data ready flag not set, function returns FALSE and value found
            FSUIPC_Get = False
        End If
    End Function

    Overloads Function FSUIPC_Get(ByRef Token As Integer, ByRef Result As Long) As Boolean
        Dim Size As Integer = 8    ' 8 bytes in a Long Int
        If (Token < 0) Or (Token > IPC_BUFFER_SIZE - (4 + Size)) Then 'Token out of range
            Result = 0
            FSUIPC_Get = False
            Exit Function
        End If
        Result = BitConverter.ToInt64(IPC, Token + 4)
        If IPCdr(Token) Then
            IPCdr(Token) = False
            FSUIPC_Get = True
        Else    ' If data ready flag not set, function returns FALSE and value found
            FSUIPC_Get = False
        End If
    End Function

    Overloads Function FSUIPC_Get(ByRef Token As Integer, ByRef Result As Double) As Boolean
        Dim Size As Integer = 8    ' 8 bytes in a Double
        Dim InBuf(8) As Byte
        Dim i As Integer
        If (Token < 0) Or (Token > IPC_BUFFER_SIZE - (4 + Size)) Then 'Token out of range
            Result = 0
            FSUIPC_Get = False
            Exit Function
        End If
        Result = BitConverter.ToDouble(IPC, Token + 4)
        If IPCdr(Token) Then
            IPCdr(Token) = False
            FSUIPC_Get = True
        Else    ' If data ready flag not set, function returns FALSE and value found
            FSUIPC_Get = False
        End If
    End Function

    'Get a byte array from IPC FIFO Buffer (i.e. String handling)
    Overloads Function FSUIPC_Get(ByRef Token As Integer, ByVal dwSize As Integer, ByRef Result As Byte()) _
                       As Boolean

        If (Token < 0) Or (Token > IPC_BUFFER_SIZE - (4 + dwSize)) Then 'Token out of range
            FSUIPC_Get = False
            Exit Function
        End If
        Dim Size As Integer
        Dim heapbuf As IntPtr = Marshal.AllocHGlobal(4)
        Marshal.Copy(IPC, Token, heapbuf, 4)
        Size = Marshal.ReadInt32(heapbuf)
        Marshal.FreeHGlobal(heapbuf)
        If dwSize > Size Then
            dwSize = Size    'Max size of return block is size of block written
        End If
        Dim idx = Token + 4    'go past size block
        While idx < Token + 4 + dwSize
            Result(idx - Token - 4) = IPC(idx)
            idx = idx + 1
        End While
        If IPCdr(Token) Then
            IPCdr(Token) = False
            FSUIPC_Get = True
        Else    ' If data ready flag not set, function returns FALSE and value found
            FSUIPC_Get = False
        End If
    End Function



    '--- Read request ---------------------------------------------------------------
    Function FSUIPC_Read(ByVal dwOffset As Integer, ByVal dwSize As Integer, ByRef Token As Integer, _
    ByRef dwResult As Integer) As Boolean

        Dim Hdr(4) As Integer

        If (IPCAlloc + dwSize + 4) >= (IPC_BUFFER_SIZE - 1) Then  'Reset ptr to start of FIFO buf
            IPCAlloc = 0
        End If
        ' Assign Token as index into IPC Buffer FIFO, and clear data ready flags
        Token = IPCAlloc
        Dim i As Integer
        For i = IPCAlloc To (IPCAlloc + 4 + dwSize - 1) ' 4=size of integer datablock size hdr
            IPC(i) = 0
            IPCdr(i) = False
        Next i
        IPCAlloc = IPCAlloc + 4 + dwSize    'first four bytes data block size (Int) plus data

        If Token >= IPC_BUFFER_SIZE Then
            Token = -1
            dwResult = FSUIPC_ERR_BUFOVERFLOW
            FSUIPC_Read = False
            Exit Function
        End If

        ' Check link is open
        If m_pView = 0 Then
            dwResult = FSUIPC_ERR_NOTOPEN
            FSUIPC_Read = False
            Exit Function
        End If

        ' Check have space for this request (including terminator)
        If ((m_pNext - m_pView + 4 + dwSize + LEN_RD_HDR) > MAX_SIZE) Then
            dwResult = FSUIPC_ERR_SIZE
            FSUIPC_Read = False
            Exit Function
        End If

        Hdr(0) = FS6IPC_READSTATEDATA_ID     'Read request ID
        Hdr(1) = dwOffset                    'FSUIPC offset
        Hdr(2) = dwSize                      'data element size
        Hdr(3) = Token                       'index into managed data buffer IPC

        Dim _pNext As IntPtr = op_Explicit(m_pNext)
        Marshal.Copy(Hdr, 0, _pNext, 4)    'Header to FSUIPC data buffer 

        ' Move pointer past the Record
        m_pNext = m_pNext + LEN_RD_HDR
        If (dwSize <> 0) Then
            ' Zero the data reception area, so rubbish won't be returned
            _pNext = op_Explicit(m_pNext)
            ZeroMemory(_pNext, dwSize)
            ' Update the pointer ready for more data
            m_pNext = m_pNext + dwSize
        End If

        dwResult = FSUIPC_ERR_OK
        FSUIPC_Read = True
    End Function


    '--- Process read/write ------------------------------------------------------
    Function FSUIPC_Process(ByVal dwResult As Integer) As Boolean
        Dim dwError As Integer
        Dim Hdr(4) As Integer
        Dim i As Integer
        If (m_pView = 0) Then
            dwResult = FSUIPC_ERR_NOTOPEN
            FSUIPC_Process = False
            Exit Function
        End If

        If (m_pView = m_pNext) Then
            dwResult = FSUIPC_ERR_NODATA
            FSUIPC_Process = False
            Exit Function
        End If

        ' Write FSUIPC Data Area Terminator
        Dim _pNext As IntPtr = op_Explicit(m_pNext)
        ZeroMemory(_pNext, 4)

        m_pNext = m_pView

        ' send the request (allow up to 10 tries)

        i = 0
        While (i < 10) And ((SendMessageTimeout(m_hWnd, m_msg, m_atom, 0&, SMTO_BLOCK, 2000, dwError)) = 0)
            '                         m_hWnd,              // FS6 window handle
            '                         m_msg,               // our registered message id
            '                         m_atom,              // wParam: name of file-mapping object
            '                         0,                   // lParam: offset of request into file-mapping obj
            '                         SMTO_BLOCK,          // halt this thread until we get a response
            '                         2000,                // time out interval
            '                         dwError)) = 0) do begin  // return value
            i = i + 1
            Sleep(100)  ' Allow for things to happen
        End While


        If (i >= 10) Then   ' Failed all tries
            If GetLastError = 0 Then dwResult = FSUIPC_ERR_TIMEOUT Else dwResult = FSUIPC_ERR_SENDMSG
            FSUIPC_Process = False
            Exit Function
        End If

        ' did IPC like the data request?
        If (dwError <> FS6IPC_MESSAGE_SUCCESS) Then
            ' no...
            dwResult = FSUIPC_ERR_DATA
            FSUIPC_Process = False
            Exit Function
        End If

        ' Decode and store results of Read requests
        m_pNext = m_pView
        _pNext = op_Explicit(m_pNext)

        Marshal.Copy(_pNext, Hdr, 0, 1)
        m_pNext = m_pNext + 4              'Advance ptr 4 bytes for Header pre-read

        ' Hdr(0) Operation ID (1=Read, 2=Write)
        ' Hdr(1) FSUIPC Offset value
        ' Hdr(2) Size of data block to pass (bytes)
        ' Hdr(3) Token (offset into IPC FIFO buffer)

        While (Hdr(0) <> 0)
            Select Case Hdr(0)
                Case FS6IPC_READSTATEDATA_ID
                    ' copy the data FSUIPC read into the local FIFO buffer
                    _pNext = op_Explicit(m_pNext)
                    Marshal.Copy(_pNext, Hdr, 1, 3)
                    m_pNext = m_pNext + LEN_RD_HDR - 4
                    If (Hdr(2) <> 0) Then
                        _pNext = op_Explicit(m_pNext)
                        Dim _nBytes As IntPtr = Marshal.AllocHGlobal(4)    'Ptr to # of bytes in record
                        Marshal.WriteInt32(_nBytes, Hdr(2))                'Write datablock size as block header
                        Marshal.Copy(_nBytes, IPC, Hdr(3), 4)              'Write data into FIFO buffer
                        Marshal.FreeHGlobal(_nBytes)
                        Marshal.Copy(_pNext, IPC, Hdr(3) + 4, Hdr(2))      'Copy data to IPC(Token)
                        IPCdr(Hdr(3)) = True                               'Flag - data available for retrieval
                    End If
                    m_pNext = m_pNext + Hdr(2)  'Increment read buffer ptr by size of data element passed

                Case FS6IPC_WRITESTATEDATA_ID
                    ' Write transaction, no return data...pull header from datastream and waste
                    _pNext = op_Explicit(m_pNext)
                    Marshal.Copy(_pNext, Hdr, 1, 2)
                    m_pNext = m_pNext + LEN_WR_HDR - 4 + Hdr(2)
                Case Else
                    ' Invalid Operation ID...abort
                    m_pNext = m_pView
                    Exit Function
            End Select
            _pNext = op_Explicit(m_pNext)
            Marshal.Copy(_pNext, Hdr, 0, 1)
            m_pNext = m_pNext + 4
        End While
        m_pNext = m_pView
        dwResult = FSUIPC_ERR_OK
        FSUIPC_Process = True
    End Function

    ' Six overloaded functions as with FSUIPC_Get


    Overloads Function FSUIPC_Write(ByVal dwOffset As Integer, ByVal Param As Byte, _
                     ByRef Token As Integer, ByRef dwResult As Integer) As Boolean

        Dim DataElementSize As Integer = 1

        If (IPCAlloc + DataElementSize + 4) >= (IPC_BUFFER_SIZE - 1) Then  'Reset ptr to startbuf
            IPCAlloc = 0
        End If
        ' Assign Token as index into IPC Buffer FIFO, and clear data ready flags
        Token = IPCAlloc
        Dim i As Integer
        For i = IPCAlloc To (IPCAlloc + 4 + DataElementSize - 1) ' 4=size of integer datablock size hdr
            IPC(i) = 0
            IPCdr(i) = False
        Next i
        IPCAlloc = IPCAlloc + 4 + DataElementSize    'first four bytes data block size (Int) plus data
        Dim BlockSizeBits(4) As Byte
        BlockSizeBits = BitConverter.GetBytes(DataElementSize)
        For i = 0 To 3
            IPC(Token + i) = BlockSizeBits(i)
        Next
        IPC(Token + 4) = Param
        FSUIPC_Write = FSUIPC_Write_Req(dwOffset, DataElementSize, Token, dwResult)
    End Function

    Overloads Function FSUIPC_Write(ByVal dwOffset As Integer, ByVal Param As Short, _
                 ByRef Token As Integer, ByRef dwResult As Integer) As Boolean

        Dim DataElementSize As Integer = 2

        If (IPCAlloc + DataElementSize + 4) >= (IPC_BUFFER_SIZE - 1) Then  'Reset ptr to startbuf
            IPCAlloc = 0
        End If
        ' Assign Token as index into IPC Buffer FIFO, and clear data ready flags
        Token = IPCAlloc
        Dim i As Integer
        For i = IPCAlloc To (IPCAlloc + 4 + DataElementSize - 1) ' 4=size of integer datablock size hdr
            IPC(i) = 0
            IPCdr(i) = False
        Next i
        IPCAlloc = IPCAlloc + 4 + DataElementSize    'first four bytes data block size (Int) plus data
        Dim BlockSizeBits(4) As Byte
        Dim ParamBits(2) As Byte
        BlockSizeBits = BitConverter.GetBytes(DataElementSize)
        ParamBits = BitConverter.GetBytes(Param)
        For i = 0 To 3
            IPC(Token + i) = BlockSizeBits(i)
        Next
        For i = 4 To 5
            IPC(Token + i) = ParamBits(i - 4)
        Next
        FSUIPC_Write = FSUIPC_Write_Req(dwOffset, DataElementSize, Token, dwResult)
    End Function

    Overloads Function FSUIPC_Write(ByVal dwOffset As Integer, ByVal Param As Integer, _
                   ByRef Token As Integer, ByRef dwResult As Integer) As Boolean

        Dim DataElementSize As Integer = 4

        If (IPCAlloc + DataElementSize + 4) >= (IPC_BUFFER_SIZE - 1) Then  'Reset ptr to startbuf
            IPCAlloc = 0
        End If
        ' Assign Token as index into IPC Buffer FIFO, and clear data + ready flags
        Token = IPCAlloc
        Dim i As Integer
        For i = IPCAlloc To (IPCAlloc + 4 + DataElementSize - 1) ' 4=size of integer datablock size hdr
            IPC(i) = 0
            IPCdr(i) = False
        Next i
        IPCAlloc = IPCAlloc + 4 + DataElementSize    'first four bytes data block size (Int) plus data
        Dim BlockSizeBits(4) As Byte
        Dim ParamBits(4) As Byte
        BlockSizeBits = BitConverter.GetBytes(DataElementSize)
        ParamBits = BitConverter.GetBytes(Param)
        For i = 0 To 3
            IPC(Token + i) = BlockSizeBits(i)
        Next
        For i = 4 To 7
            IPC(Token + i) = ParamBits(i - 4)
        Next

        FSUIPC_Write = FSUIPC_Write_Req(dwOffset, DataElementSize, Token, dwResult)
    End Function

    Overloads Function FSUIPC_Write(ByVal dwOffset As Integer, ByVal Param As Long, _
                   ByRef Token As Integer, ByRef dwResult As Integer) As Boolean

        Dim DataElementSize As Integer = 8

        If (IPCAlloc + DataElementSize + 4) >= (IPC_BUFFER_SIZE - 1) Then  'Reset ptr to startbuf
            IPCAlloc = 0
        End If
        ' Assign Token as index into IPC Buffer FIFO, and clear data ready flags
        Token = IPCAlloc
        Dim i As Integer
        For i = IPCAlloc To (IPCAlloc + 4 + DataElementSize - 1) ' 4=size of integer datablock size hdr
            IPC(i) = 0
            IPCdr(i) = False
        Next i
        IPCAlloc = IPCAlloc + 4 + DataElementSize    'first four bytes data block size (Int32) plus data
        Dim BlockSizeBits(4) As Byte
        Dim ParamBits(8) As Byte
        BlockSizeBits = BitConverter.GetBytes(DataElementSize)
        ParamBits = BitConverter.GetBytes(Param)
        For i = 0 To 3
            IPC(Token + i) = BlockSizeBits(i)
        Next
        For i = 4 To 11
            IPC(Token + i) = ParamBits(i - 4)
        Next
        FSUIPC_Write = FSUIPC_Write_Req(dwOffset, DataElementSize, Token, dwResult)
    End Function

    Overloads Function FSUIPC_Write(ByVal dwOffset As Integer, ByVal Param As Double, _
                   ByRef Token As Integer, ByRef dwResult As Integer) As Boolean

        Dim DataElementSize As Integer = 8

        If (IPCAlloc + DataElementSize + 4) >= (IPC_BUFFER_SIZE - 1) Then  'Reset ptr to startbuf
            IPCAlloc = 0
        End If
        ' Assign Token as index into IPC Buffer FIFO, and clear data ready flags
        Token = IPCAlloc
        Dim i As Integer
        For i = IPCAlloc To (IPCAlloc + 4 + DataElementSize - 1) ' 4=size of integer datablock size hdr
            IPC(i) = 0
            IPCdr(i) = False
        Next i
        IPCAlloc = IPCAlloc + 4 + DataElementSize    'first four bytes data block size (Int) plus data
        Dim BlockSizeBits(4) As Byte
        Dim ParamBits(8) As Byte
        BlockSizeBits = BitConverter.GetBytes(DataElementSize)
        ParamBits = BitConverter.GetBytes(Param)
        For i = 0 To 3
            IPC(Token + i) = BlockSizeBits(i)
        Next
        For i = 4 To 11
            IPC(Token + i) = ParamBits(i - 4)
        Next
        FSUIPC_Write = FSUIPC_Write_Req(dwOffset, DataElementSize, Token, dwResult)
    End Function


    Overloads Function FSUIPC_Write(ByVal dwOffset As Integer, ByVal dwSize As Integer, ByVal Param As Byte(), _
                   ByRef Token As Integer, ByRef dwResult As Integer) As Boolean

        If (IPCAlloc + dwSize + 4) >= (IPC_BUFFER_SIZE - 1) Then  'Reset ptr to startbuf
            IPCAlloc = 0
        End If
        ' Assign Token as index into IPC Buffer FIFO, and clear data ready flags
        Token = IPCAlloc
        Dim i As Integer
        For i = IPCAlloc To (IPCAlloc + 4 + dwSize - 1) ' 4=size of integer datablock size hdr
            IPC(i) = 0
            IPCdr(i) = False
        Next i
        IPCAlloc = IPCAlloc + 4 + dwSize    'first four bytes data block size (Int) plus data
        Dim BlockSizeBits(4) As Byte
        BlockSizeBits = BitConverter.GetBytes(dwSize)
        For i = 0 To 3
            IPC(Token + i) = BlockSizeBits(i)
        Next
        For i = (Token + 4) To (Token + dwSize + 3)
            IPC(i) = Param(i - Token - 4)       'xfer byte array to IPC managed FIFO buffer
        Next i
        FSUIPC_Write = FSUIPC_Write_Req(dwOffset, dwSize, Token, dwResult)
    End Function


    '--- Internal Write request ------------------------------------------------------
    Function FSUIPC_Write_Req(ByVal dwOffset As Integer, ByVal dwSize As Integer, _
             ByVal Token As Integer, ByRef dwResult As Integer) As Boolean

        Dim Hdr(4) As Integer

        If Token >= IPC_BUFFER_SIZE Then
            Token = -1
            dwResult = FSUIPC_ERR_BUFOVERFLOW
            FSUIPC_Write_Req = False
            Exit Function
        End If

        ' abort if necessary
        If m_pView = 0 Then
            dwResult = FSUIPC_ERR_NOTOPEN
            FSUIPC_Write_Req = False
            Exit Function
        End If

        ' Check have FSUIPC buffer space for this request (including terminator)
        If ((((m_pNext) - (m_pView)) + 4 + (dwSize + LEN_WR_HDR)) > MAX_SIZE) Then
            dwResult = FSUIPC_ERR_SIZE
            FSUIPC_Write_Req = False
            Exit Function
        End If

        ' Initialise header for write request

        Hdr(0) = FS6IPC_WRITESTATEDATA_ID
        Hdr(1) = dwOffset
        Hdr(2) = dwSize

        Dim _pNext As IntPtr = op_Explicit(m_pNext)
        Marshal.Copy(Hdr, 0, _pNext, 3)    'Write header to FSUIPC data buffer
        ' Move pointer past the record
        m_pNext = m_pNext + LEN_WR_HDR
        If (dwSize <> 0) Then
            _pNext = op_Explicit(m_pNext)    'convert int index to ptr into FSUIPC buffer
            Marshal.Copy(IPC, Token + 4, _pNext, dwSize)
            ' Update the pointer ready for more data
            m_pNext = m_pNext + dwSize
        End If
        dwResult = FSUIPC_ERR_OK
        FSUIPC_Write_Req = True
    End Function


    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub



End Class

