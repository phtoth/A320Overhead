package com.flightsim.fsuipc;
/*
Copyright 2002 Mark Burton
*/



public class FSEngine3 extends FSEngine
	{
	public FSEngine3()
	{
	super();
	iMixAddress=0x9c0;
	iStartAddress=0x9c2;
	iCombustionAddress=0x9c4;
	}
	}
