package com.flightsim.fsuipc;
/*
Copyright 2002 Mark Burton
*/



public class FSEngine1 extends FSEngine
	{
	public FSEngine1()
	{
	super();
	iMixAddress=0x890;
	iStartAddress=0x892;
	iCombustionAddress=0x894;
	iValueOffset = 0x088c;
	}
	}
