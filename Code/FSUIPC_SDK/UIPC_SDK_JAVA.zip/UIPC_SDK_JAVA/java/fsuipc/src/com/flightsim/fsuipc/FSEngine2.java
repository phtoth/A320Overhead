package com.flightsim.fsuipc;
/*
Copyright 2002 Mark Burton
*/



public class FSEngine2 extends FSEngine
	{
	public FSEngine2()
	{
	super();
	iMixAddress=0x928;
	iStartAddress=0x92a;
	iCombustionAddress=0x92c;
	}
	}
